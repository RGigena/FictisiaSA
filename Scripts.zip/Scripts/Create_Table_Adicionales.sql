USE [Clientes_Fictisia]
GO

/****** Object:  Table [dbo].[Adicionales]    Script Date: 20/03/2025 10:22:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Adicionales](
	[adicionalesId] [int] IDENTITY(1,1) NOT NULL,
	[maneja] [bit] NOT NULL,
	[usaLentes] [bit] NOT NULL,
	[esDiabetico] [bit] NOT NULL,
	[otraEnfermedad] [bit] NOT NULL,
	[comentarios] [nvarchar](max) NULL,
 CONSTRAINT [PK_Adicionales] PRIMARY KEY CLUSTERED 
(
	[adicionalesId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


